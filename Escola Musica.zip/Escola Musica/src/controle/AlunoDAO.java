/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import negocio.Aluno;
import negocio.ConFactory;

/**
 *
 * @author Emanuelly
 */
public class AlunoDAO implements IAlunoDAO {
     private Connection connection;
    
    public AlunoDAO(){
        this.connection = new ConFactory().getConnection();
    }
    
    @Override
    public void adiciona(Aluno aluno){
        
        String sql = "insert into aluno" +
                "(nomeAluno, cpfAluno, data_nascimento, sexo, enderecoAluno, telefoneAluno, curso, observacoes, data_cadastro)" +
                " values (?,?,?,?,?,?,?,?, now())";
        
        try{
            PreparedStatement stmt = connection.prepareStatement(sql);
            
            stmt.setString(1,aluno.getNomeAluno());
            stmt.setString(2,aluno.getCpfAluno());
            stmt.setDate(3, new Date(aluno.getData_nascimento().getTimeInMillis()));
            stmt.setString(4,aluno.getSexo());
            stmt.setString(5,aluno.getEnderecoAluno());
            stmt.setString(6,aluno.getTelefoneAluno());
            stmt.setString(7,aluno.getCurso());
            stmt.setString(8,aluno.getObservacoes());
            
            stmt.execute();
            stmt.close();
        } catch(SQLException e){
            throw new RuntimeException(e);
        }
    }

    @Override
    public void altera(Aluno aluno) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void remove(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Aluno> listarTodos() {
        throw new UnsupportedOperationException("Not supported yet.");
//         try {
//            List<Aluno> aluno = new ArrayList<Aluno>();
//            PreparedStatement stmt = this.connection.
//            prepareStatement("select * from aluno");
//            ResultSet rs = stmt.executeQuery();
//            
//            while(rs.next()){
//                
//                Aluno aluno = new Aluno();
//                aluno.setMatricula(rs.getInt("matricula"));
//                aluno.setNomeAluno(rs.getString("nomeAluno"));
//                aluno.setCpfAluno(rs.getString("cpfAluno"));
//                
//                Calendar data = Calendar.getInstance();
//                data.setTime(rs.getDate("data_nascimento"));
//                aluno.setData_nascimento(data);
//                
//                aluno.setSexo(rs.getString("sexo"));
//                aluno.setEnderecoAluno(rs.getString("enderecoAluno"));
//                aluno.setTelefoneAluno(rs.getString("telefoneAluno"));
//                aluno.setCurso(rs.getString("curso"));
//                aluno.setObservacoes(rs.getString("observacoes"));
//                data.setTime(rs.getDate("data_cadastro"));
//                aluno.setData_cadastro(data);
//                
//                aluno.add(aluno);
//            }
//            rs.close();
//            stmt.close();
//            return alunos;
//        }catch (SQLException e){
//            throw new RuntimeException (e);
//        }
    }

    @Override
    public Aluno getByID(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
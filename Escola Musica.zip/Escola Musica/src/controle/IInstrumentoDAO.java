/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;
import java.util.List;
import negocio.Instrumento;
/**
 *
 * @author Emanuelly
 */
public interface IInstrumentoDAO {
    public void adiciona(Instrumento instrumento);
    public void altera(Instrumento instrumento);
    public void remove(int id);
    public List<Instrumento> listarTodos();
    public Instrumento getByID(int id);
}

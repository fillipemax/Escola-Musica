/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import negocio.Administrador;
import negocio.ConFactory;

/**
 *
 * @author Emanuelly
 */
public class AdministradorDAO implements IAdministradorDAO{
    private Connection connection;
    
    public AdministradorDAO(){
        this.connection = new ConFactory().getConnection();
    }
@Override
    public void adiciona(Administrador administrador){
        String sql = "insert into administrador" +
                "(nomeadm, cpfadm, loginadm, senhaadm)" +
                " values (?,?,?,?)";
        
        try{
            PreparedStatement stmt = connection.prepareStatement(sql);
            
            stmt.setString(1,administrador.getNomeAdm());
            stmt.setString(2,administrador.getCpfAdm());
            stmt.setString(3,administrador.getLoginAdm());
            stmt.setString(4,administrador.getSenhaAdm());
            
            stmt.execute();
            stmt.close();
        } catch(SQLException e){
            throw new RuntimeException(e);
        }
    }

    @Override
    public void altera(Administrador administrador) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void remove(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Administrador> listarTodos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Administrador getByID(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    } 
}


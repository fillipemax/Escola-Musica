/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;
import java.util.List;
import negocio.Aluno;

/**
 *
 * @author Emanuelly
 */
public interface IAlunoDAO {
    public void adiciona(Aluno aluno);
    public void altera(Aluno aluno);
    public void remove(int id);
    public List<Aluno> listarTodos();
    public Aluno getByID(int id);
}

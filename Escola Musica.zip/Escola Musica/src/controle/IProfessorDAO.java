/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;
import java.util.List;
import negocio.Professor;
/**
 *
 * @author Emanuelly
 */
public interface IProfessorDAO {
    public void adiciona(Professor professor);
    public void altera(Professor professor);
    public void remove(int id);
    public List<Professor> listarTodos();
    public Professor getByID(int id);
}

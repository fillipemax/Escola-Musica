/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;
import negocio.Aluno;
import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Emanuelly
 */
public class main {
    public static void main(String[] args) throws SQLException {
        Connection conexao = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/escolamusica", "root","manu1306");
        System.out.println("Conectado!");
        conexao.close();

    }
}

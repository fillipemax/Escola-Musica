/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;
import java.util.Calendar;
/**
 *
 * @author Emanuelly
 */
public class Instrumento {
    
    private int idInstrumento;
    private String tipo;

    /**
     * @return the idInstrumento
     */
    public int getIdInstrumento() {
        return idInstrumento;
    }

    /**
     * @param idInstrumento the idInstrumento to set
     */
    public void setIdInstrumento(int idInstrumento) {
        this.idInstrumento = idInstrumento;
    }

    /**
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;

/**
 *
 * @author Emanuelly
 */
public class Administrador {
    private int idAdm;
    private String nomeAdm;
    private String cpfAdm;
    private String loginAdm;
    private String senhaAdm;

    /**
     * @return the idAdm
     */
    public int getIdAdm() {
        return idAdm;
    }

    /**
     * @param idAdm the idAdm to set
     */
    public void setIdAdm(int idAdm) {
        this.idAdm = idAdm;
    }

    /**
     * @return the nomeAdm
     */
    public String getNomeAdm() {
        return nomeAdm;
    }

    /**
     * @param nomeAdm the nomeAdm to set
     */
    public void setNomeAdm(String nomeAdm) {
        this.nomeAdm = nomeAdm;
    }

    /**
     * @return the cpfAdm
     */
    public String getCpfAdm() {
        return cpfAdm;
    }

    /**
     * @param cpfAdm the cpfAdm to set
     */
    public void setCpfAdm(String cpfAdm) {
        this.cpfAdm = cpfAdm;
    }

    /**
     * @return the loginAdm
     */
    public String getLoginAdm() {
        return loginAdm;
    }

    /**
     * @param loginAdm the loginAdm to set
     */
    public void setLoginAdm(String loginAdm) {
        this.loginAdm = loginAdm;
    }

    /**
     * @return the senhaAdm
     */
    public String getSenhaAdm() {
        return senhaAdm;
    }

    /**
     * @param senhaAdm the senhaAdm to set
     */
    public void setSenhaAdm(String senhaAdm) {
        this.senhaAdm = senhaAdm;
    }
}
